﻿using System;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace teste_comunicação
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort;
        private StreamReader streamReader;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Executa();

        }
        private void Executa()
        {
            serialPort = new SerialPort("COM3", 115200);
            serialPort.Open();
            streamReader = new StreamReader(serialPort.BaseStream);
            Task.Run(async () => await ReadSerialDataAsync());
        }
        private async Task ReadSerialDataAsync()
        {
            while (true)
            {
                // Aguarda a leitura de uma linha de texto da porta serial
                string data = await streamReader.ReadLineAsync();
                if (data == "1")
                {
                    MessageBox.Show(data);
                }
                else
                {

                    if (textBox1.InvokeRequired)
                    {
                        textBox1.Invoke(new Action(() =>
                        {
                            textBox1.AppendText(data + Environment.NewLine);
                        }));
                    }
                    else
                    {
                        textBox1.AppendText(data + Environment.NewLine);
                    }
                }
            }
        }

            private void button1_Click(object sender, EventArgs e)
        {
            var teste = new teste1();
            serialPort.Close();
            teste.ShowDialog();
            Executa();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort.Write("1");
        }
    }
}
