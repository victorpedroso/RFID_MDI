﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace testeEsp32
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocorreu um erro" + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conexao.Write("0");
        }

        private void conexao_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            this.Invoke(new EventHandler(respostaEsp));
        }
        private void respostaEsp(object o, EventArgs e)
        {
            string data = conexao.ReadLine().Replace("\r", "");
            if(data.Length == 8)
            {
                //faz conexao com o bd e verifica se tag existe, se existir envia 2
                //se não existir envia 3
            }
            else
            {
                //o cadastro da tag será em nova tela
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            conexao.Close();
        }
    }
}
